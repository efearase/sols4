from django.http import HttpResponse

def index(request):
    return HttpResponse("111111")

def test(request):
    return HttpResponse("This is test.")
from django.db import models
from django.utils import timezone
import datetime


class Article(models.Model):
    article_title = models.CharField("Article's name", max_length=128)
    article_text = models.TextField("Article's text")
    pub_date = models.DateTimeField("Publication's date")

    def __str__(self):
        return self.article_title

    def was_published_recently(self):
        return self.pub_date >= (timezone.now() - datetime.timedelta(days=7))


class Comment(models.Model):
    article = models.ForeignKey(Article, on_delete=models.CASCADE)
    author_name = models.CharField("Author's name", max_length=128)
    comment_text = models.TextField()

    def __str__(self):
        return self.author_name
